---
name: Sentinel Path
colors:
  surface: '#f7f9fb'
  surface-dim: '#d8dadc'
  surface-bright: '#f7f9fb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f6'
  surface-container: '#eceef0'
  surface-container-high: '#e6e8ea'
  surface-container-highest: '#e0e3e5'
  on-surface: '#191c1e'
  on-surface-variant: '#45464d'
  inverse-surface: '#2d3133'
  inverse-on-surface: '#eff1f3'
  outline: '#76777d'
  outline-variant: '#c6c6cd'
  surface-tint: '#565e74'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#131b2e'
  on-primary-container: '#7c839b'
  inverse-primary: '#bec6e0'
  secondary: '#515f74'
  on-secondary: '#ffffff'
  secondary-container: '#d5e3fc'
  on-secondary-container: '#57657a'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#370e00'
  on-tertiary-container: '#e45405'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dae2fd'
  primary-fixed-dim: '#bec6e0'
  on-primary-fixed: '#131b2e'
  on-primary-fixed-variant: '#3f465c'
  secondary-fixed: '#d5e3fc'
  secondary-fixed-dim: '#b9c7df'
  on-secondary-fixed: '#0d1c2e'
  on-secondary-fixed-variant: '#3a485b'
  tertiary-fixed: '#ffdbce'
  tertiary-fixed-dim: '#ffb599'
  on-tertiary-fixed: '#370e00'
  on-tertiary-fixed-variant: '#7f2b00'
  background: '#f7f9fb'
  on-background: '#191c1e'
  surface-variant: '#e0e3e5'
  surface-dark: '#1E293B'
  border-subtle: '#E2E8F0'
  text-main: '#161616'
  safety-orange-muted: '#FB923C'
typography:
  display:
    fontFamily: Hanken Grotesk
    fontSize: 48px
    fontWeight: '800'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Hanken Grotesk
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
  headline-lg-mobile:
    fontFamily: Hanken Grotesk
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
  headline-md:
    fontFamily: Hanken Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Hanken Grotesk
    fontSize: 20px
    fontWeight: '400'
    lineHeight: 30px
  body-md:
    fontFamily: Hanken Grotesk
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-caps:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.05em
  button:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 20px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  container-max: 1280px
  gutter: 1.5rem
  margin-mobile: 1rem
  margin-desktop: 2.5rem
  stack-sm: 0.5rem
  stack-md: 1.5rem
  stack-lg: 3rem
---

## Brand & Style

This design system is built on a foundation of **Modern Professionalism** with a **Protective** core. It rejects the alarmist tropes of the legal and insurance industries, opting instead for a calm, authoritative presence that feels like a reliable toolkit for professionals. The aesthetic is clean, structured, and utilitarian, prioritizing clarity and speed of comprehension over decorative flourish.

The visual direction follows a **Corporate / Modern** style with a hint of **Minimalism**. It uses generous whitespace to reduce cognitive load, ensuring that users—often accessing the platform from mobile devices in high-stress or outdoor environments—can find critical information instantly. The design avoids "busy" elements, focusing on high-contrast layouts and a structured hierarchy that conveys stability and trust.

## Colors

The palette is anchored by **Dark Navy (#0F172A)** to project authority and institutional trust. **Slate (#475569)** provides a professional bridge between the deep primary tones and the light backgrounds, used primarily for secondary information and icons.

**Restrained Safety Orange (#EA580C)** serves as the high-visibility accent. It is reserved strictly for primary actions and critical alerts, ensuring it commands attention without inducing panic. The background utilizes a very light grey **(#F8FAFC)** to reduce screen glare compared to pure white, which is essential for viewing in varying light conditions like truck cabs. All text-to-background combinations are strictly vetted to meet **WCAG AAA** standards for maximum legibility.

## Typography

The typography system utilizes **Hanken Grotesk** for its exceptional legibility and modern, sharp terminals that convey precision. The type scale is intentionally oversized to accommodate Chromebook users and outdoor viewing.

For body text, we maintain a minimum size of **16px**, scaling up to **20px** for introductory paragraphs to ensure ease of reading. **Inter** is used for functional labels and micro-copy due to its systematic and neutral appearance. Headings use a tighter letter-spacing and heavier weights to create a sense of structural "anchoring" on the page.

## Layout & Spacing

The system employs a **12-column fluid grid** for desktop and a **single-column stack** for mobile. A strict 8px spacing power-of-two scale is used to maintain rhythm. 

- **Mobile (< 640px):** 16px margins, fluid containers.
- **Tablet (640px - 1024px):** 24px margins, 2-column card layouts.
- **Desktop (> 1024px):** 40px margins with a maximum content width of 1280px to prevent line lengths from becoming unreadable.

Content is organized into vertical "stacks" with clear separation between logical sections (Benefit Cards vs. FAQ), using `stack-lg` to provide a clear visual break.

## Elevation & Depth

To maintain a "Practical" and "Modern" feel, the design system avoids heavy shadows and skeuomorphism. Instead, it uses **Tonal Layers** and **Low-contrast outlines**.

- **Level 0 (Background):** Light grey (#F8FAFC) or White.
- **Level 1 (Cards/Containers):** White background with a 1px solid border (#E2E8F0).
- **Level 2 (Interactive/Hover):** A subtle, highly diffused shadow (0px 4px 12px rgba(15, 23, 42, 0.05)) is applied only to indicate interactivity.
- **Alerts:** Use a solid side-border of Safety Orange to denote importance without lifting the element off the page.

Depth is used sparingly to signify importance, not decoration.

## Shapes

The shape language is defined by **Rounded (0.5rem)** corners. This radius is soft enough to feel approachable and modern, but sharp enough to maintain a sense of professional structure. 

- **Primary Buttons:** Use the standard 0.5rem radius.
- **Cards/Accordions:** Use the `rounded-lg` (1rem) for a more protective, "encapsulated" feel.
- **Input Fields:** Maintain 0.5rem for consistency with buttons.
- **Icons:** Should be encased in a circular or 0.5rem rounded square background when used as part of a feature list.

## Components

### Buttons
- **Primary:** Solid Dark Navy background with White text. Bold and high-contrast.
- **Secondary:** Transparent background with a Slate border and text.
- **Action:** Safety Orange for critical "Join" or "Contact" triggers.

### Content & Benefit Cards
Cards should have a 1px border and generous internal padding (min 24px). Benefit cards feature a Slate-colored icon in the top-left, followed by a `headline-md` title and `body-md` description.

### FAQ Accordions
Clean, flat rows separated by a subtle horizontal rule. Use a chevron icon that rotates on expansion. The header area remains active for the full width to facilitate easy mobile tapping.

### Timeline & Progress
For the "Career Protection" process, use a vertical stepped timeline with solid Dark Navy nodes. Completed steps are marked with a simple check icon.

### Pricing Cards
The "Recommended" tier is highlighted with a 2px Safety Orange top border and a "Most Popular" label using the `label-caps` style. Prices should be high-contrast and utilize the `display` font size.

### Navigation
- **Mobile:** A "Sticky" bottom bar for the most critical actions (Join, Support) and a standard hamburger menu for resources.
- **Desktop:** A clean, centered horizontal nav with a prominent Primary Button in the top right.